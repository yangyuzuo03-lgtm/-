# codex-pet-sage
download sage.zip → unzip it → move the folder to your pets folder
